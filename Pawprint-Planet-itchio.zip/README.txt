Pawprint Planet: Miso & Pete’s Vet Skills Lab

This is an HTML game for itch.io. Upload this ZIP as an HTML game and leave index.html at the archive root and keep the included assets folder beside it. Choose between Miso the cat and Pete the giraffe. Each case includes a routine checkup, X-ray lesson, treatment cards, mini quiz, a patient-specific hands-on treatment activity, and a Doctor’s Note saved to the casebook. Pete’s route includes a tummy examination and a spoon-feeding simulation for pretend vet-selected medicine. Pete’s supplied giraffe character art and Miso’s supplied cat character art have transparent backgrounds. Both appear as the patient character and in the zoomed heartbeat scene; Pete also appears in his tummy and medicine scenes. A third sticky note records the patient’s weight after the scale activity and stays visible through the rest of the case.

The game is self-contained. Display fonts load from Google Fonts when the player is online.
