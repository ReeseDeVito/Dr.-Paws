Pawprint Planet: Miso’s Cast Lab

This is an HTML game for itch.io. Upload this ZIP as an HTML game and leave index.html at the archive root. The game includes a page-by-page routine checkup, an interactive bruise inspection with a persistent learner note, a vet-guided cast simulation, and a free-form Doctor’s Note saved with Miso’s casebook entry.

The game is self-contained. Display fonts load from Google Fonts when the player is online.
